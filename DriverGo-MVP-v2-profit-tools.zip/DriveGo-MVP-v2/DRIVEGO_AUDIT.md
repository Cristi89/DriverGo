# DriveGo — audit e modifiche

## Correzioni applicate
- Risolto il crash in `SearchResults`: le coordinate venivano lette prima di estrarre i parametri della navigazione.
- Aggiunto un controllo per parametri origine/destinazione mancanti.
- Aggiunto `fare: Float` allo schema GraphQL sorgente, perché il client lo salva nella mutation ma il modello server originale non lo dichiarava.
- Corretto il flusso stati dell'autista per usare gli stati persistiti (`DRIVER_ARRIVED`, `IN_PROGRESS`, `COMPLETED`) invece di proprietà locali non presenti nello schema (`pickedUp`, `isFinished`).
- Sostituita la chiave Google Maps incorporata nel sorgente con `YOUR_GOOGLE_MAPS_API_KEY`; va configurata con una chiave propria e restrizioni appropriate.
- Aggiornate le istruzioni di setup, collaudo e limiti noti.

## Punti critici ancora aperti
1. **Backend non deployato da questo archivio.** La modifica allo schema GraphQL richiede una revisione e un `amplify push` verso l'ambiente corretto. Non è stato possibile verificare un backend AWS remoto.
2. **Assegnazione corsa:** `carId: "1"` è ancora un segnaposto richiesto dall'attuale schema. Va sostituito con un modello che permetta ordini non assegnati e assegnazione atomica lato server.
3. **Autista/veicolo:** manca una schermata di onboarding per creare e configurare il record `Car`; va predisposto nel backend per il collaudo.
4. **Sicurezza:** autenticazione e autorizzazioni AppSync devono impedire agli utenti di modificare ordini altrui o assegnare corse arbitrariamente.
5. **Prezzi e produzione:** tariffa client-side solo indicativa; mancano pagamenti, push, cancellazioni, monitoraggio, test automatizzati di flusso e gestione background GPS.
6. **Stack legacy:** React Native 0.63 e dipendenze Amplify v3 sono datati e richiedono una strategia di aggiornamento prima della pubblicazione.

## Esito
Il repository è stato corretto nei punti di blocco più evidenti, ma non può essere dichiarato completamente pronto per la produzione senza configurare/deployare il backend e completare i punti critici sopra.
