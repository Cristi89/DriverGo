# DriveGo MVP

Acesta este un MVP bazat pe proiectul UberClone. Conține aplicație client (UserApp) și aplicație șofer (DriverApp).

## Flux inclus
1. Clientul alege punctul de plecare și destinația.
2. Se calculează distanța aproximativă și un tarif estimativ pentru UberX/Comfort/UberXL.
3. Clientul creează comanda cu status NEW.
4. Șoferul vede comenzile NEW și poate accepta una.
5. Șoferul își poate activa/dezactiva disponibilitatea și trimite poziția GPS în backend.
6. Șoferul poate marca sosirea și finalizarea cursei.
7. Clientul primește actualizările prin GraphQL subscriptions.

## Configurare necesară înainte de APK
- Configurează proiectul AWS Amplify/AppSync pentru cele două aplicații.
- Configurează cheia Google Maps/Places și restricționeaz-o pentru Android/iOS.
- Rulează `yarn install` în fiecare aplicație.
- Pentru Android: `yarn android`.

## Important
Tariful è un preventivo locale nel client; per un'app reale va spostato nel backend e va aggiunto un sistema di pagamento.
