# DriveGo – MVP transport app

This project is based on the supplied UberClone React Native project and is branded as DriveGo.

## Apps
- UserApp: passenger app – account, map, destination search, route selection, vehicle type, trip request and trip tracking.
- DriverApp: driver app – account, vehicle registration, availability, new-trip requests, acceptance and live location updates.

## Backend
The project uses AWS Amplify/AppSync/Cognito. The original UserApp contained an Amplify configuration; it is also copied to DriverApp so both apps point at the same backend.

## Google Maps
The source project contains a Google Maps API key. For a real release, replace it with a key owned by you and restrict it by Android/iOS app and API. Do not publish the sample key as your production key.

## Important
This is an MVP starting point, not a production-ready ride-hailing service. Before public launch you still need production authentication rules, payments, pricing logic, driver verification, privacy/terms, push notifications, fraud protection, server-side matching, and proper background location handling.
