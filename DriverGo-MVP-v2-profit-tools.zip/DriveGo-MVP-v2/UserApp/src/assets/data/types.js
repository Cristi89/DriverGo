export default [
  {
    id: '0',
    type: 'UberX',
    price: 12,
    duration: 20,
  },
  {
    id: '1',
    type: 'Comfort',
    price: 16,
    duration: 18,
  },
  {
    id: '2',
    type: 'UberXL',
    price: 22,
    duration: 25,
  },
]
