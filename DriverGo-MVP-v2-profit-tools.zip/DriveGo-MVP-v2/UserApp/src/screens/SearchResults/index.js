import React, { useState } from 'react';
import {View, Text, Dimensions} from 'react-native';
import { API, graphqlOperation, Auth } from 'aws-amplify';
import RouteMap from "../../components/RouteMap";
import UberTypes from "../../components/UberTypes";
import { createOrder } from '../../graphql/mutations';
import { haversineKm, estimateFare } from '../../utils';

import { useRoute, useNavigation } from '@react-navigation/native';

const SearchResults = (props) => {
  const typeState = useState(null);
  const route = useRoute();
  const navigation = useNavigation();
  const { originPlace, destinationPlace } = route.params || {};

  if (!originPlace?.details?.geometry?.location || !destinationPlace?.details?.geometry?.location) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 }}>
        <Text>Seleziona di nuovo il punto di partenza e la destinazione.</Text>
      </View>
    );
  }

  const origin = { latitude: originPlace.details.geometry.location.lat, longitude: originPlace.details.geometry.location.lng };
  const destination = { latitude: destinationPlace.details.geometry.location.lat, longitude: destinationPlace.details.geometry.location.lng };
  const distanceKm = haversineKm(origin, destination);
  const fares = {
    UberX: estimateFare('UberX', distanceKm),
    Comfort: estimateFare('Comfort', distanceKm),
    UberXL: estimateFare('UberXL', distanceKm),
  };

  const onSubmit = async () => {
    const [type] = typeState;
    if (!type) {
      return;
    }

    // submit to server
    try {
      const userInfo = await Auth.currentAuthenticatedUser();

      const date = new Date();
      const input = {
        createdAt: date.toISOString(),
        type,
        originLatitude: originPlace.details.geometry.location.lat,
        oreiginLongitude: originPlace.details.geometry.location.lng,

        destLatitude: destinationPlace.details.geometry.location.lat,
        destLongitude: destinationPlace.details.geometry.location.lng,

        userId: userInfo.attributes.sub,
        carId: "1",
        status: "NEW",
        fare: fares[type],
      }

      const response = await API.graphql(
        graphqlOperation(
          createOrder, {
            input: input
          },
        )
      )



      navigation.navigate('OrderPage', { id: response.data.createOrder.id });
    } catch (e) {
      console.error(e);
    }
  }

  return (
    <View style={{display: 'flex', justifyContent: 'space-between'}}>
      <View style={{height: Dimensions.get('window').height - 400}}>
        <RouteMap origin={originPlace} destination={destinationPlace} />
      </View>

      <View style={{height: 400}}>
        <UberTypes typeState={typeState} onSubmit={onSubmit} fares={fares} />
      </View>
    </View>
  );
};

export default SearchResults;
