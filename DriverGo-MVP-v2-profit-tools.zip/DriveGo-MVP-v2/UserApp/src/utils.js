export const haversineKm = (a, b) => {
  const toRad = value => value * Math.PI / 180;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
};

export const estimateFare = (type, km) => {
  const rates = {
    UberX: { base: 3.0, perKm: 1.25 },
    Comfort: { base: 4.0, perKm: 1.55 },
    UberXL: { base: 5.0, perKm: 1.85 },
  };
  const rate = rates[type] || rates.UberX;
  return Math.max(rate.base, rate.base + km * rate.perKm);
};
