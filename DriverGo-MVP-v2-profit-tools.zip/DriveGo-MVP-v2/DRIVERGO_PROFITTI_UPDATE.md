# DriverGo — aggiornamento funzionalità profitti

Questa revisione aggiunge una schermata accessibile dal pulsante del saldo sulla mappa:
- inserimento manuale di incasso, chilometri, durata e spese;
- stima del netto, netto orario e costo spese per chilometro;
- riepiloghi giornalieri e mensili delle corse inserite;
- analisi indicativa dell'offerta basata sui valori inseriti.

## Limiti importanti
- I dati sono in memoria e non vengono salvati in modo permanente: chiudendo la schermata o riavviando l'app, il registro può andare perso.
- L'analisi non legge automaticamente screenshot: il riconoscimento OCR non è incluso.
- Non è stata eseguita una build Android in questo ambiente. Il progetto originale usa React Native 0.63.4 e contiene configurazione Google Maps segnaposto e dipendenze/backend AWS da verificare.
- Questa modifica non rende automaticamente l'app pronta per la produzione.

Per creare un APK, usare il workflow Android già presente in `.github/workflows/android-apk.yml` dopo aver caricato il progetto aggiornato nel repository.
