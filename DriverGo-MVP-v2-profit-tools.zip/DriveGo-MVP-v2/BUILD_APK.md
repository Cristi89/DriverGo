# Build DriveGo APKs

This repository contains two React Native Android apps:

- `UserApp`: passenger app
- `DriverApp`: driver app

## Build locally

Requirements: Node.js 16, Java 11, Android SDK with `platforms;android-29` and `build-tools;29.0.2`, plus network access for Gradle and package downloads.

For each app, install JavaScript dependencies and run the Android debug build:

```bash
cd UserApp
yarn install --frozen-lockfile
cd android
./gradlew assembleDebug
```

Then repeat for `DriverApp`.

Expected outputs:

- `UserApp/android/app/build/outputs/apk/debug/app-debug.apk`
- `DriverApp/android/app/build/outputs/apk/debug/app-debug.apk`

## Build using GitHub Actions

The workflow `.github/workflows/android-apk.yml` builds both debug APKs and publishes them as the `DriveGo-Android-APKs` workflow artifact. Push the project to a GitHub repository, then open **Actions → Build DriveGo Android APKs → Run workflow**. Download the artifact from the completed run.

These are debug APKs, not signed production releases. Before public distribution, configure production API keys, backend permissions, app signing, and verify both apps against the real AWS backend.
