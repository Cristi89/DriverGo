import React, { useState, useEffect } from "react";
import { View, Text, Dimensions, Pressable, TextInput, ScrollView } from "react-native";
import MapView, { PROVIDER_GOOGLE } from "react-native-maps";
import MapViewDirections from 'react-native-maps-directions';
import Entypo from "react-native-vector-icons/Entypo";
import Ionicons from "react-native-vector-icons/Ionicons";
import styles from './styles.js'
import NewOrderPopup from "../../components/NewOrderPopup";
import FontAwesome from "react-native-vector-icons/FontAwesome";

import { Auth, API, graphqlOperation } from 'aws-amplify';
import { getCar, listOrders } from '../../graphql/queries';
import { updateCar, updateOrder } from '../../graphql/mutations';

const GOOGLE_MAPS_APIKEY = 'YOUR_GOOGLE_MAPS_API_KEY';

const ProfitabilityScreen = ({ onBack }) => {
  const [fare, setFare] = useState('');
  const [km, setKm] = useState('');
  const [minutes, setMinutes] = useState('');
  const [expenses, setExpenses] = useState('');
  const [trips, setTrips] = useState([]);
  const [tab, setTab] = useState('trip');
  const money = n => '€' + Number(n || 0).toFixed(2);
  const net = Number(fare || 0) - Number(expenses || 0);
  const hourly = Number(minutes || 0) > 0 ? net / (Number(minutes) / 60) : 0;
  const today = new Date().toDateString();
  const daily = trips.filter(t => t.date === today);
  const monthly = trips.filter(t => t.month === new Date().getMonth() && t.year === new Date().getFullYear());
  const total = list => list.reduce((sum, t) => sum + t.net, 0);
  const field = (label, value, setter, hint) => <View style={{marginBottom:12}}>
    <Text style={{color:'#344054',marginBottom:5,fontWeight:'600'}}>{label}</Text>
    <TextInput value={value} onChangeText={setter} keyboardType="decimal-pad" placeholder={hint}
      style={{backgroundColor:'#fff',borderColor:'#d0d5dd',borderWidth:1,borderRadius:9,padding:11,color:'#101828'}} />
  </View>;
  return <View style={{position:'absolute',top:0,left:0,right:0,bottom:0,backgroundColor:'#f2f4f7',zIndex:99}}>
    <View style={{backgroundColor:'#101828',padding:18,paddingTop:42,flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}>
      <Text style={{fontSize:20,color:'#fff',fontWeight:'bold'}}>DriverGo · Profitti</Text>
      <Pressable onPress={onBack}><Text style={{color:'#fff',fontSize:16}}>← Mappa</Text></Pressable>
    </View>
    <View style={{flexDirection:'row',padding:10}}>
      {['trip','stats','offer'].map(key => <Pressable key={key} onPress={()=>setTab(key)} style={{flex:1,marginHorizontal:3,padding:10,borderRadius:8,backgroundColor:tab===key?'#175cd3':'#fff',alignItems:'center'}}>
        <Text style={{color:tab===key?'#fff':'#344054',fontWeight:'600'}}>{key==='trip'?'Registra':key==='stats'?'Statistiche':'Offerta'}</Text>
      </Pressable>)}
    </View>
    <ScrollView contentContainerStyle={{padding:16,paddingBottom:40}}>
      {tab==='trip' && <>
        <Text style={{fontSize:17,fontWeight:'bold',color:'#101828',marginBottom:12}}>Registra una corsa</Text>
        {field('Incasso (€)',fare,setFare,'es. 18,50')}{field('Chilometri percorsi',km,setKm,'es. 12')}
        {field('Durata in minuti',minutes,setMinutes,'es. 25')}{field('Spese (€)',expenses,setExpenses,'carburante, commissioni, pedaggi')}
        <View style={{backgroundColor:'#fff',padding:15,borderRadius:12,marginBottom:12}}>
          <Text style={{color:'#475467'}}>Guadagno netto stimato</Text><Text style={{fontSize:27,fontWeight:'bold',color:net>=0?'#039855':'#d92d20'}}>{money(net)}</Text>
          <Text style={{color:'#475467',marginTop:5}}>Guadagno orario: {money(hourly)}/h · Costo/km: {Number(km)>0?money(Number(expenses)/Number(km)):'—'}</Text>
        </View>
        <Pressable onPress={()=>{if(fare.trim()===''||Number(fare)<0||Number(km)<0||Number(minutes)<0||Number(expenses)<0)return;setTrips(prev=>[...prev,{fare:Number(fare),km:Number(km||0),minutes:Number(minutes||0),expenses:Number(expenses||0),net,date:today,month:new Date().getMonth(),year:new Date().getFullYear()}]);setFare('');setKm('');setMinutes('');setExpenses('');}}
          style={{backgroundColor:'#175cd3',padding:15,borderRadius:10,alignItems:'center'}}><Text style={{color:'#fff',fontWeight:'bold'}}>Salva corsa</Text></Pressable>
        <Text style={{color:'#667085',marginTop:10,fontSize:12}}>Nota: per ora i dati restano in memoria solo mentre la schermata è aperta; non chiudere la schermata se vuoi consultare le statistiche.</Text>
      </>}
      {tab==='stats' && <>
        <Text style={{fontSize:18,fontWeight:'bold',color:'#101828',marginBottom:12}}>Riepilogo</Text>
        {[['Oggi',daily],['Questo mese',monthly],['Tutte le corse',trips]].map(([label,list])=><View key={label} style={{backgroundColor:'#fff',padding:16,borderRadius:12,marginBottom:12}}>
          <Text style={{color:'#475467'}}>{label}</Text><Text style={{fontSize:25,fontWeight:'bold',color:'#101828'}}>{money(total(list))}</Text>
          <Text style={{color:'#667085'}}>{list.length} corse · Incassi {money(list.reduce((a,t)=>a+t.fare,0))} · Spese {money(list.reduce((a,t)=>a+t.expenses,0))}</Text>
          <Text style={{color:'#667085'}}>Distanza: {list.reduce((a,t)=>a+t.km,0).toFixed(1)} km</Text>
        </View>)}
      </>}
      {tab==='offer' && <View>
        <Text style={{fontSize:18,fontWeight:'bold',color:'#101828',marginBottom:8}}>Analisi dell'offerta</Text>
        <Text style={{color:'#475467',marginBottom:14}}>Inserisci importo, chilometri, durata e spese nella scheda Registra per stimare la convenienza.</Text>
        <View style={{backgroundColor:'#fff',padding:16,borderRadius:12}}>
          <Text style={{fontSize:16,fontWeight:'bold',color:'#101828'}}>Valutazione indicativa</Text>
          <Text style={{marginTop:8,color:'#344054'}}>Netto stimato: {money(net)}</Text><Text style={{color:'#344054'}}>Netto orario: {money(hourly)}/h</Text>
          <Text style={{color:'#667085',marginTop:8}}>{net<=0?'Da rivedere: le spese assorbono l’incasso.':hourly>0&&hourly<12?'Margine orario contenuto: valuta distanza e tempo.':'Confronta il netto orario con il tuo obiettivo e considera anche il tragitto a vuoto.'}</Text>
          <Text style={{color:'#667085',marginTop:10}}>Il riconoscimento automatico da screenshot non è ancora incluso.</Text>
        </View>
      </View>}
    </ScrollView>
  </View>;
};

const HomeScreen = () => {
  const [showProfit, setShowProfit] = useState(false);
  const [car, setCar] = useState(null);
  const [myPosition, setMyPosition] = useState(null);
  const [order, setOrder] = useState(null)
  const [newOrders, setNewOrders] = useState([]);

  const fetchCar = async () => {
    try {
      const userData = await Auth.currentAuthenticatedUser();
      const carData = await API.graphql(
        graphqlOperation(getCar, { id: userData.attributes.sub }),
      );
      setCar(carData.data.getCar);
    } catch (e) {
      console.error(e);
    }
  }

  const fetchOrders = async () => {
    try {
        const ordersData = await API.graphql(
          graphqlOperation(
            listOrders,
            { filter: { status: { eq: 'NEW'}}}
            )
        );
        setNewOrders(ordersData.data.listOrders.items);
    } catch (e) {
      console.log(e);
    }
  }

  useEffect(() => {
    fetchCar();
    fetchOrders();
  }, []);

  const onDecline = () => {
    setNewOrders(newOrders.slice(1));
  }

  const onAccept = async (newOrder) => {
    if (!car?.id) {
      console.warn('Configura prima il veicolo del conducente prima di accettare corse.');
      return;
    }
    try {
      const input = {
        id: newOrder.id,
        status: "PICKING_UP_CLIENT",
        carId: car.id
      }
      const orderData = await API.graphql(
        graphqlOperation(updateOrder, { input })
      )
      setOrder(orderData.data.updateOrder);
    } catch (e) {
      console.error('Impossibile accettare la corsa:', e);
      return;
    }

    setNewOrders(newOrders.slice(1));
  }

  const onGoPress = async () => {
    if (!car) {
      console.warn('Veicolo non configurato: crea il record Car prima di andare online.');
      return;
    }
    // Update the car and set it to active
    try {
      const userData = await Auth.currentAuthenticatedUser();
      const input = {
        id: userData.attributes.sub,
        isActive: !car.isActive,
      }
      const updatedCarData = await API.graphql(
        graphqlOperation(updateCar, { input })
      )
      setCar(updatedCarData.data.updateCar);
    } catch (e) {
      console.error(e);
    }
  }

  const onUserLocationChange = async (event) => {
    const { latitude, longitude, heading } = event.nativeEvent.coordinate
    // Update the car and set it to active
    try {
      const userData = await Auth.currentAuthenticatedUser();
      const input = {
        id: userData.attributes.sub,
        latitude,
        longitude,
        heading,
      }
      const updatedCarData = await API.graphql(
        graphqlOperation(updateCar, { input })
      )
      setCar(updatedCarData.data.updateCar);
    } catch (e) {
      console.error(e);
    }
  }

  const updateOrderStatus = async (status) => {
    if (!order) return;
    try {
      const response = await API.graphql(graphqlOperation(updateOrder, { input: { id: order.id, status } }));
      setOrder(response.data.updateOrder);
    } catch (e) {
      console.error(e);
    }
  };

  const onDirectionFound = (event) => {
    if (order) {
      setOrder(current => current ? {
        ...current,
        distance: event.distance,
        duration: event.duration,
      } : current);
    }
  }

  const getDestination = () => {
    if (order && order.status === 'IN_PROGRESS') {
      return {
        latitude: order.destLatitude,
        longitude: order.destLongitude,
      }
    }
    return {
      latitude: order.originLatitude,
      longitude: order.oreiginLongitude,
    }
  }

  const renderBottomTitle = () => {
    if (order && order.status === 'COMPLETED') {
      return (
        <View style={{ alignItems: 'center' }}>
          <View style={{flexDirection: 'row', alignItems: 'center',justifyContent: 'center', backgroundColor: '#cb1a1a', width: 200, padding: 10,  }}>
            <Text style={{color: 'white', fontWeight: 'bold'}}>COMPLETE {order.type}</Text>
          </View>
          <Text style={styles.bottomText}>{order.user.username}</Text>
        </View>
      )
    }

    if (order && order.status === 'IN_PROGRESS') {
      return (
        <View style={{ alignItems: 'center' }}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text>{order.duration ? order.duration.toFixed(1) : '?'} min</Text>
            <View style={{ backgroundColor: '#d41212', marginHorizontal: 10, width: 30, height: 30, alignItems:'center', justifyContent: 'center', borderRadius: 20}}>
              <FontAwesome name={"user"} color={"white"} size={20} />
            </View>
            <Text>{order.distance ? order.distance.toFixed(1) : '?'} km</Text>
          </View>
          <Text style={styles.bottomText}>Dropping off {order?.user?.username}</Text>
        </View>
      )
    }

    if (order) {
      return (
        <View style={{ alignItems: 'center' }}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text>{order.duration ? order.duration.toFixed(1) : '?'} min</Text>
            <View style={{ backgroundColor: '#1e9203', marginHorizontal: 10, width: 30, height: 30, alignItems:'center', justifyContent: 'center', borderRadius: 20}}>
              <FontAwesome name={"user"} color={"white"} size={20} />
            </View>
            <Text>{order.distance ? order.distance.toFixed(1) : '?'} km</Text>
          </View>
          <Text style={styles.bottomText}>Picking up {order?.user?.username}</Text>
        </View>
      )
    }
    if (car?.isActive) {
      return (
        <Text style={styles.bottomText}>You're online</Text>
      )
    }
    return (<Text style={styles.bottomText}>You're offline</Text>);
  }

  return (
    <View>
      <MapView
        style={{width: '100%', height: Dimensions.get('window').height - 150}}
        provider={PROVIDER_GOOGLE}
        showsUserLocation={true}
        onUserLocationChange={onUserLocationChange}
        initialRegion={{
          latitude: 28.450627,
          longitude: -16.263045,
          latitudeDelta: 0.0222,
          longitudeDelta: 0.0121,
        }}
      >
        {order && (
          <MapViewDirections
            origin={{
              latitude: car?.latitude,
              longitude: car?.longitude,
            }}
            onReady={onDirectionFound}
            destination={getDestination()}
            apikey={GOOGLE_MAPS_APIKEY}
            strokeWidth={5}
            strokeColor="black"
          />
        )}
      </MapView>

      <Pressable
        onPress={() => setShowProfit(true)}
        style={styles.balanceButton}>
        <Text style={styles.balanceText}>
          <Text style={{ color: 'green' }}>€</Text>
          {' '}
          Profitti
        </Text>
      </Pressable>

      <Pressable
        onPress={() => console.warn('Hey')}
        style={[styles.roundButton, {top: 10, left: 10}]}>
        <Entypo name={"menu"} size={24} color="#4a4a4a"/>
      </Pressable>

      <Pressable
        onPress={() => console.warn('Hey')}
        style={[styles.roundButton, {top: 10, right: 10}]}>
        <Entypo name={"menu"} size={24} color="#4a4a4a"/>
      </Pressable>

      <Pressable
        onPress={() => console.warn('Hey')}
        style={[styles.roundButton, {bottom: 110, left: 10}]}>
        <Entypo name={"menu"} size={24} color="#4a4a4a"/>
      </Pressable>

      <Pressable
        onPress={() => console.warn('Hey')}
        style={[styles.roundButton, {bottom: 110, right: 10}]}>
        <Entypo name={"menu"} size={24} color="#4a4a4a"/>
      </Pressable>

      <Pressable
        onPress={onGoPress}
        style={styles.goButton}>
        <Text style={styles.goText}>
          {car?.isActive ? 'END' : 'GO'}
        </Text>
      </Pressable>

      {order && !['DRIVER_ARRIVED', 'IN_PROGRESS', 'COMPLETED'].includes(order.status) && (
        <Pressable onPress={() => updateOrderStatus('DRIVER_ARRIVED')} style={[styles.goButton, {bottom: 175, width: 180}]}>
          <Text style={styles.goText}>AM AJUNS</Text>
        </Pressable>
      )}

      {order && order.status === 'DRIVER_ARRIVED' && (
        <Pressable onPress={() => updateOrderStatus('IN_PROGRESS')} style={[styles.goButton, {bottom: 175, width: 180}]}>
          <Text style={styles.goText}>ÎNCEPE CURSA</Text>
        </Pressable>
      )}

      {order && order.status === 'IN_PROGRESS' && (
        <Pressable onPress={() => updateOrderStatus('COMPLETED')} style={[styles.goButton, {bottom: 175, width: 180}]}>
          <Text style={styles.goText}>FINALIZEAZĂ CURSA</Text>
        </Pressable>
      )}

      <View style={styles.bottomContainer}>
        <Ionicons name={"options"} size={30} color="#4a4a4a"/>
          {renderBottomTitle()}
        <Entypo name={"menu"} size={30} color="#4a4a4a" />
      </View>

      {showProfit && <ProfitabilityScreen onBack={() => setShowProfit(false)} />}

      {newOrders.length > 0 && !order && <NewOrderPopup
        newOrder={newOrders[0]}
        duration={2}
        distance={0.5}
        onDecline={onDecline}
        onAccept={() => onAccept(newOrders[0])}
      />}
    </View>
  );
};

export default HomeScreen;
